﻿# A10 session handoff

Checkout when this pack was made: main @ 4a08ad3. No A10 branch exists yet.

## Session opener

Continue A10 Career/Jobs (A10_LISTING). Plan: plan/a10_listings_implementation_2a54acf1.plan.md. Checkout is main @ 4a08ad3; create feature/m3-a10-listings; selectively port from origin/m3-changes 3fa3016; do not cherry-pick that commit or merge m3-changes. Renumber migrations after main tips. ADR-0012 for A10 (0010 wallet, 0011 A7/A9). Contract proposal 0016. Listing is not a Booking. Owner runs pytest. Never git add -A. Leave srikar-prompts/ untracked.

## Layout

- plan/ — locked implementation plan
- from-main/ — repo files that exist on main
- from-m3-remotes/ — design authority and Cloud Agent stubs not on main
- prior-audits/ — takeover + git-pace reports
